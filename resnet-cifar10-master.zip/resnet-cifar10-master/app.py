import os
import io
import base64

os.environ.pop("TF_USE_LEGACY_KERAS", None)
os.environ["KERAS_BACKEND"] = "tensorflow"

from flask import Flask, render_template, request
from PIL import Image
import numpy as np
import keras
from keras import layers, models

app = Flask(__name__)

MODEL_PATH = "cifar10_model.keras"

CLASS_NAMES = [
    "máy bay",
    "ô tô",
    "chim",
    "con mèo",
    "con nai",
    "con chó",
    "con ếch",
    "con ngựa",
    "con tàu",
    "xe tải",
]


# Residual Block
def residual_block(x, filters, stride=1):
    shortcut = x

    x = layers.Conv2D(filters, kernel_size=3, strides=stride, padding="same")(x)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)

    x = layers.Conv2D(filters, kernel_size=3, strides=1, padding="same")(x)
    x = layers.BatchNormalization()(x)

    if stride != 1 or shortcut.shape[-1] != filters:
        shortcut = layers.Conv2D(filters, kernel_size=1, strides=stride, padding="same")(shortcut)
        shortcut = layers.BatchNormalization()(shortcut)

    x = layers.Add()([x, shortcut])
    x = layers.ReLU()(x)
    return x


# Build ResNet Model
def build_resnet(input_shape=(32, 32, 3), num_classes=10):
    inputs = layers.Input(shape=input_shape)

    x = layers.Conv2D(64, kernel_size=3, strides=1, padding="same")(inputs)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)

    x = residual_block(x, 64)
    x = residual_block(x, 64)
    x = layers.Dropout(0.25)(x)

    x = residual_block(x, 128, stride=2)
    x = residual_block(x, 128)
    x = layers.Dropout(0.25)(x)

    x = residual_block(x, 256, stride=2)
    x = residual_block(x, 256)
    x = layers.Dropout(0.25)(x)

    x = residual_block(x, 512, stride=2)
    x = residual_block(x, 512)
    x = layers.Dropout(0.25)(x)

    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)

    model = models.Model(inputs, outputs, name="cifar10_resnet")
    return model


def load_inference_model():
    if not os.path.exists(MODEL_PATH):
        return None, f"Không tìm thấy file mô hình: {MODEL_PATH}"

    try:
        model = build_resnet()
        model.load_weights(MODEL_PATH)
        return model, None
    except Exception as e_weights:
        try:
            model = keras.models.load_model(MODEL_PATH, compile=False)
            return model, None
        except Exception as e_model:
            error_message = (
                "Không thể tải mô hình.\n\n"
                f"- Lỗi khi load_weights(): {e_weights}\n\n"
                f"- Lỗi khi load_model(): {e_model}"
            )
            return None, error_message


model, model_error = load_inference_model()


def preprocess_image(image: Image.Image):
    image = image.convert("RGB")
    image = image.resize((32, 32))
    img_array = np.array(image, dtype=np.float32) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array


@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    confidence = None
    top3 = []
    uploaded_image = None
    error = model_error

    if request.method == "POST":
        file = request.files.get("image")

        if file is None or file.filename == "":
            error = "Vui lòng chọn một ảnh để tải lên."
            return render_template(
                "index.html",
                prediction=prediction,
                confidence=confidence,
                top3=top3,
                uploaded_image=uploaded_image,
                error=error,
            )

        try:
            file_bytes = file.read()
            if not file_bytes:
                raise ValueError("File ảnh rỗng.")

            mime_type = file.mimetype if file.mimetype else "image/png"
            encoded_img = base64.b64encode(file_bytes).decode("utf-8")
            uploaded_image = f"data:{mime_type};base64,{encoded_img}"

            image = Image.open(io.BytesIO(file_bytes))

            if model is None:
                error = model_error
            else:
                x = preprocess_image(image)
                preds = model.predict(x, verbose=0)[0]

                pred_idx = int(np.argmax(preds))
                prediction = CLASS_NAMES[pred_idx]
                confidence = float(preds[pred_idx]) * 100

                top_indices = np.argsort(preds)[::-1][:3]
                top3 = [
                    {
                        "label": CLASS_NAMES[i],
                        "score": float(preds[i]) * 100,
                    }
                    for i in top_indices
                ]

        except Exception as e:
            error = f"Không thể xử lý ảnh: {e}"

    return render_template(
        "index.html",
        prediction=prediction,
        confidence=confidence,
        top3=top3,
        uploaded_image=uploaded_image,
        error=error,
    )


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)